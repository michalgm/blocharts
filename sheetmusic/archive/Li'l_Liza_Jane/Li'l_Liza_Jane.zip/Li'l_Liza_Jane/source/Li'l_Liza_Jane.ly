\version "2.12.3"

\header { 
	tagline = "1/31/2014"
	title = "Li'l Liza Jane"
	composer = "Traditional"
	copyright = "7/1/10" %date of latest edits
	}

%description:A traditional New Orleans Second Line tune of unknown origin.

%place a mark at bottom right
markdownright = { \once \override Score.RehearsalMark #'break-visibility = #begin-of-line-invisible \once \override Score.RehearsalMark #'self-alignment-X = #RIGHT \once \override Score.RehearsalMark #'direction = #DOWN }


% music pieces
%part: melody
melody = {
	\relative c' { \key f \major
	\partial 8*3 f8 g f |

	\mark \default %A
	\repeat volta 2 {
		a4-^ f-^ g8 g f4 | a4-^ f8 g r g f4 | a c2 d8 c | r2 r8 f, g f |
		a4-^ f-^ g8 g f4 | a4-^ f8 g r g f4 | a a2 g8 f | }
		\alternative {
			{ r2 r8 f g f | }
			{ r1 }
		}
	
	\mark \default %B
	\repeat volta 2 {
		r4 f'2 c4 | d4. c8~ c4 r | a c2 d8 c | r1 |
		r4 f2 c4 | d4. c8~ c4 r | a a2 g8 f \markdownright \mark \markup { \italic "fine" } | }
		\alternative {
			{ r1 }
			{ r2 r8 
				<<
				{ c'^\markup { \small \italic "on to C" } d c }
				\\
				{ f,_\markup { \small \italic "back to A" } g f }
				>>
			}
		}

	\mark \default %C
	\repeat volta 2 {
		\repeat unfold 2 { <aes c ees>2.~~~ <aes c ees>8 <f aes c> | r2 r8 <f aes c> <g bes d> <f aes c> | }
		<aes c ees>2.~~~ <aes c ees>8 <f aes c> | r1 | 
		<aes c ees>4 <aes c ees> <g c e> <g e'>8 <f f'> | }
		\alternative {
			{ r2 r8 <f aes c> <g bes d> <f aes c> | }
			{ r2 r8 f g f | }
		}
	}
}

%part: bass
bass = {
	\relative c { 
		\partial 8*3 r4. |

		\mark \default %A
		\repeat volta 2 {
			f,4 r f f | r c'2 d4 | f, r f f | r ees'2 e4 |
			f,4 r f f | r c'2 d4 | f, r f f | }
			\alternative {
				{ r ees'2 e4 | }
				{ r ees2 e4 | }
			}

		\mark \default %B
		\repeat volta 2 {
			f,4 r f f | r c'2 d4 | f, r f f | r ees'2 e4 |
			f,4 r f f | r c'2 d4 | f, r f f \markdownright \mark \markup { \italic "fine" } | }
			\alternative {
				{ r ees'2 e4 | }
				{ r ees2 e4 | }
			}

		\mark \default %C	
		\repeat volta 2 {
			f4 r c r | f r8 c~ c4 e | f4 r c r | f r8 c~ c4 e | 
			f4 r c r | f r8 c~ c4 e | f4 r c r | }
			\alternative {
				{ f r8 c~ c4 e | }
				{ f ees2 e4 | }
			}
	}
}

%part: words
words = \markup { }

%part: changes
changes = \chordmode { }

%%Generated layout
#(set-default-paper-size "letter")
\book {
	\score { <<
			\set Score.markFormatter = #format-mark-box-numbers
			
		\new Staff \with { \consists "Volta_engraver" } {  \set Staff.midiInstrument = #"trumpet" \clef treble
			\tempo  4 = 200 
			\override Score.RehearsalMark #'self-alignment-X = #LEFT
			\melody
		}
		\new Staff \with { \consists "Volta_engraver" } {  \set Staff.midiInstrument = #"tuba" \clef bass
			\override Score.RehearsalMark #'self-alignment-X = #LEFT
			\bass
		}
	>> \layout { \context { \Score \remove "Volta_engraver" } } }  
}